<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Login extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->helper('url');
        $this->load->library(['form_validation', 'session']);
    }

    public function index()
    {
        $this->load->view('form/v_login');
    }

    public function login()
    {
        $this->form_validation->set_rules('username', 'Username', 'required');
        $this->form_validation->set_rules('pwd', 'Password', 'required');
        $this->form_validation->set_error_delimiters('<div class="error">', '</div>');

        if ($this->form_validation->run() == TRUE) {
            $usr = $this->input->post('username');
            $pwd = $this->input->post('pwd');

            if ($usr == 'admin' && $pwd == 'adm1n321') {
                $this->load->view('form/v_signup');
            } else {
                $message['message'] = "Invalid username or password.";
                $this->load->view('form/v_login', $message);
            }
        } else {
            $this->load->view('form/v_login');
        }
    }

    public function signup()
    {
        $this->form_validation->set_rules('npm', 'NPM', 'required');
        $this->form_validation->set_rules('nama', 'Nama', 'required');
        $this->form_validation->set_rules('jurusan', 'Jurusan', 'required');
        $this->form_validation->set_rules('gender', 'Jenis Kelamin', 'required');
        $this->form_validation->set_rules('uts', 'Nilai UTS', 'required|numeric');
        $this->form_validation->set_rules('uas', 'Nilai UAS', 'required|numeric');
        $this->form_validation->set_rules('tugas', 'Nilai Tugas', 'required|numeric');
        $this->form_validation->set_rules('kehadiran', 'Nilai Kehadiran', 'required|numeric');

        if ($this->form_validation->run() == TRUE) {
            $uts = $this->input->post('uts');
            $uas = $this->input->post('uas');
            $tugas = $this->input->post('tugas');
            $kehadiran = $this->input->post('kehadiran');

            $nakhir = ($uts * 0.3) + ($uas * 0.4) + ($tugas * 0.2) + ($kehadiran / 14 * 0.1);
            $nilai_huruf = '';

            if ($nakhir <= 40) {
                $nilai_huruf = 'E';
            } elseif ($nakhir <= 55) {
                $nilai_huruf = 'D';
            } elseif ($nakhir <= 60) {
                $nilai_huruf = 'C';
            } elseif ($nakhir <= 65) {
                $nilai_huruf = 'C+';
            } elseif ($nakhir <= 70) {
                $nilai_huruf = 'B-';
            } elseif ($nakhir <= 75) {
                $nilai_huruf = 'B+';
            } elseif ($nakhir <= 80) {
                $nilai_huruf = 'B+';
            } elseif ($nakhir <= 85) {
                $nilai_huruf = 'A-';
            } elseif ($nakhir <= 100) {
                $nilai_huruf = 'A';
            } else {
                $nilai_huruf = 'Tidak Valid';
            }
            

            $data = [
                'npm' => $this->input->post('npm'),
                'nama' => $this->input->post('nama'),
                'jurusan' => $this->input->post('jurusan'),
                'gender' => $this->input->post('gender'),
                'uts' => $uts,
                'uas' => $uas,
                'tugas' => $tugas,
                'kehadiran' => $kehadiran,
                'nakhir' => $nakhir,
                'nilai_huruf' => $nilai_huruf
            ];

            $this->session->set_userdata('form_data', $data);
            redirect('form/login/hasil');
        } else {
            $this->load->view('form/v_signup');
        }
    }

    public function hasil()
    {
        $data = $this->session->userdata('form_data');
        if ($data) {
            $this->load->view('form/v_hasil', ['data' => $data]);
        } else {
            redirect('login/signup');
        }
    }
}
