<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kartu Hasil Studi</title>
    <link rel="stylesheet" href="<?= base_url('assets/css/bootstrap.min.css') ?>" />
</head>

<body>
    <div class="container mt-5">
        <h1>Kartu Hasil Studi</h1>

        <div id="login">
            <form id="login_form" method="post" action="<?php echo base_url(); ?>index.php/form/login/signup">
                <div class="mb-3">
                    <label for="npm" class="form-label">NPM</label>
                    <input type="text" class="form-control" id="npm" name="npm" placeholder="NPM">
                </div>
                <div class="mb-3">
                    <label for="nama" class="form-label">Nama</label>
                    <input type="text" class="form-control" id="nama" name="nama" placeholder="Nama">
                </div>
                <div class="mb-3">
                    <label for="jurusan" class="form-label">Jurusan</label>
                    <input type="text" class="form-control" id="jurusan" name="jurusan" placeholder="Jurusan">
                </div>
                <div class="mb-3">
                    <p class="form-label">Jenis Kelamin</p>
                    <div class="form-check">
                        <input class="form-check-input" type="radio" id="female" name="gender" value="female">
                        <label class="form-check-label" for="female">Perempuan</label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="radio" id="male" name="gender" value="male">
                        <label class="form-check-label" for="male">Laki-laki</label>
                    </div>
                </div>
                <div class="mb-3">
                    <label for="uts" class="form-label">Nilai UTS</label>
                    <input type="number" class="form-control" id="uts" name="uts" placeholder="Nilai UTS">
                </div>
                <div class="mb-3">
                    <label for="uas" class="form-label">Nilai UAS</label>
                    <input type="number" class="form-control" id="uas" name="uas" placeholder="Nilai UAS">
                </div>
                <div class="mb-3">
                    <label for="tugas" class="form-label">Nilai Tugas</label>
                    <input type="number" class="form-control" id="tugas" name="tugas" placeholder="Nilai Tugas">
                </div>
                <div class="mb-3">
                    <label for="kehadiran" class="form-label">Nilai Kehadiran</label>
                    <input type="number" class="form-control" id="kehadiran" name="kehadiran" placeholder="Nilai Kehadiran">
                </div>
                <button type="submit" class="btn btn-primary">Submit</button>
                <button type="submit" class="btn btn-primary">Reset</button>
            </form>
        </div>
    </div>

    
</body>

</html>
