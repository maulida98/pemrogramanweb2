<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hasil Kartu Studi</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
    <style>
        body {
            margin: 0;
            padding: 0;
            background-color: #7AB2B2;
            font-family: 'Poppins', 'Arial', sans-serif;
        }
        .container {
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            background-color: #EEF7FF;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        h1 {
            text-align: center;
            color: #000;
            margin-bottom: 20px;
        }
        .card {
            background-color: #fff;
            border: none;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            padding: 20px;
            margin-bottom: 20px;
        }
        .card-body {
            padding: 0;
        }
        .card-text {
            margin: 10px 0;
            color: #000;
        }
        .card-text strong {
            color: #000;
        }
        .button {
            text-align: center;
            margin-top: 20px;
        }
        .button a {
            text-decoration: none;
            color: #fff;
            background-color: #4D869C;
            padding: 10px 20px;
            border-radius: 5px;
            transition: background-color 0.3s;
        }
        .button a:hover {
            background-color: #000;
            color: #fff;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Welcome : <?= htmlspecialchars($data['nama']) ?></h1>

        <div class="card">
            <div class="card-body">
                <p class="card-text"><strong>NPM    :   </strong> <?= htmlspecialchars($data['npm']) ?></p>
                <p class="card-text"><strong>Nama   :   </strong> <?= htmlspecialchars($data['nama']) ?></p>
                <p class="card-text"><strong>Jurusan    :   </strong> <?= htmlspecialchars($data['jurusan']) ?></p>
                <p class="card-text"><strong>Jenis Kelamin  :   </strong> <?= htmlspecialchars($data['gender'] == 'male' ? 'Laki-laki' : 'Perempuan') ?></p>
                <p class="card-text"><strong>Nilai UTS  :   </strong> <?= htmlspecialchars($data['uts']) ?></p>
                <p class="card-text"><strong>Nilai UAS  :   </strong> <?= htmlspecialchars($data['uas']) ?></p>
                <p class="card-text"><strong>Nilai Tugas    :   </strong> <?= htmlspecialchars($data['tugas']) ?></p>
                <p class="card-text"><strong>Nilai Kehadiran    :   </strong> <?= htmlspecialchars($data['kehadiran']) ?></p>
                <p class="card-text"><strong>Nilai Akhir    :   </strong> <?= htmlspecialchars($data['nakhir']) ?></p>
                <p class="card-text"><strong>Siswa mendapatkan nilai    :   </strong> <?= htmlspecialchars($data['nilai_huruf']) ?></p>
            </div>
        </div>

        <div class="button">
            <a href="<?= base_url('index.php/form/login/signup') ?>">Kembali ke Form</a>
        </div>
    </div>
</body>
</html>
